﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Week02.Models
{
    public class User 
    {
        public string ID_kh { get; set; }
        public string Ten_kh { get; set; }
        public string Email_kh { get; set; }
        public string Sdt_kh { get; set; }
        public string Diachi_kh { get; set; }
        public string Ngaysinh_kh { get; set; }
        public string Mk_kh { get; set; }
        public string PQuyen_kh { get; set; }
    }
}