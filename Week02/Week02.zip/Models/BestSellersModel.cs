﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Week02.Models
{
    public partial class BestSellersModel
    {
        public string Ten_sp { get; set; }
        public int ID_sp { get; set; }
        public int So_luong { get; set; }
    }
}